#include "pared.h"

pared::pared()
{

}

pared::pared(int x, int y, int w, int h)
    : QGraphicsRectItem(x, y, w, h)
{
    this->posx=x;
    this->posy=y;
    this->h=h;
    this->w=w;
    currentTexture=QPixmap(":/Imagen/muro.jpg");
    setBrush(QBrush(currentTexture));
}

QRectF pared::boundingRect() const
{
    return QRectF(posx,posy,w,h);
}

void pared::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(boundingRect(), currentTexture, currentTexture.rect());
}

void pared::setTexture(const QString& texturePath)
{
    currentTexture=QPixmap(texturePath);
    setBrush(QBrush(currentTexture));
    update();
}
