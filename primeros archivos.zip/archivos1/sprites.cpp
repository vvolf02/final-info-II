#include "sprites.h"

sprites::sprites(const QPixmap &spriteSheet, int rows, int cols, int numFrames, int frameWidth, int frameHeight)
    : spriteSheet(spriteSheet),
    rows(rows),
    cols(cols),
    numFrames(numFrames),
    frameWidth(frameWidth),
    frameHeight(frameHeight),
    currentFrame(0),
    currentDirection(0)
{
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &sprites::updateFrame);
    setPixmap(spriteSheet.copy(0, 0, frameWidth, frameHeight));
}

void sprites::startAnimation()
{
    timer->start(100); // Cambia el frame cada 100ms
}

void sprites::stopAnimation()
{
    timer->stop();
}

void sprites::setDirection(int direction)
{
    if (direction != currentDirection) {
        currentDirection = direction;
        currentFrame = 0;
    }
}

void sprites::updateFrame()
{
    int frameX = (currentFrame % numFrames) * frameWidth;
    int frameY = currentDirection * frameHeight;
    setPixmap(spriteSheet.copy(frameX, frameY, frameWidth, frameHeight));

    currentFrame = (currentFrame + 1) % numFrames;
}
