#include "mc.h"

mc::mc(int x, int y, int vel)
    : sprites(QPixmap(":/Imagen/personajes.png"), 4, 3, 3, 16, 24), // Tamaño de cada sprite es 48x48
    vel(vel),
    posx(x),
    posy(y),
    vely(0)
{
    setPos(posx, posy);
    startAnimation();
}

void mc::MoverArriba()
{
    setDirection(3); // Suponiendo que la fila 4 en la imagen es para moverse arriba
    posy -= vel;
    setPos(posx, posy);
}

void mc::MoverAbajo()
{
    setDirection(0); // Suponiendo que la fila 1 en la imagen es para moverse abajo
    posy += vel;
    setPos(posx, posy);
}

void mc::MoverIzq()
{
    setDirection(1); // Suponiendo que la fila 2 en la imagen es para moverse a la izquierda
    posx -= vel;
    setPos(posx, posy);
}

void mc::MoverDer()
{
    setDirection(2); // Suponiendo que la fila 3 en la imagen es para moverse a la derecha
    posx += vel;
    setPos(posx, posy);
}

void mc::respawn()
{
    posx=20;
    posy=269;
    setPos(posx,posy);
}

void mc::caer()
{
    posy+=vely;
    setPos(posx, posy);
}

void mc::saltar()
{
    vely=velSalto; // Establecer la velocidad inicial del salto
}

void mc::nuevovy(int vy)
{
    vely = vy;
}

int mc::getVel() const
{
    return vel;
}

int mc::getX() const
{
    return posx;
}

int mc::getY() const
{
    return posy;
}

int mc::getVely() const
{
    return vely;
}
