#include "candelabro.h"

candelabro::candelabro(int x, int y, int longitud, int radio, double anguloInicial)
    : origenX(x), origenY(y), longitud(longitud), radio(radio), angulo(anguloInicial),
    velocidadAngular(0), aceleracionAngular(0), gravedad(0.4) // Ajusta la gravedad según sea necesario
{
    setPos(origenX, origenY);
}

QRectF candelabro::boundingRect() const
{
    return QRectF(-radio, -longitud - radio, 2 * radio, longitud + 2 * radio);
}

void candelabro::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option);
    Q_UNUSED(widget);

    // Dibuja la cuerda
    painter->drawLine(0, 0, longitud * sin(angulo), longitud * cos(angulo));

    // Dibuja el péndulo
    painter->setBrush(Qt::black);
    painter->drawEllipse(QPointF(longitud * sin(angulo), longitud * cos(angulo)), radio, radio);
}

void candelabro::actualizar()
{
    // Actualiza la física del péndulo
    aceleracionAngular = (-1 * gravedad / longitud) * sin(angulo);
    velocidadAngular += aceleracionAngular;
    angulo += velocidadAngular;

    // Añadir amortiguamiento
    velocidadAngular *= 0.99;

    // Redibujar el péndulo
    update();
}
