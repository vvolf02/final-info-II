#ifndef CANDELABRO_H
#define CANDELABRO_H

#include <QGraphicsItem>
#include <QPainter>
#include <cmath>

class candelabro : public QGraphicsItem
{
public:
    candelabro(int x, int y, int longitud, int radio, double anguloInicial);

    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    void actualizar();

private:
    int origenX;
    int origenY;
    int longitud;
    int radio;
    double angulo;
    double velocidadAngular;
    double aceleracionAngular;
    double gravedad;
};

#endif // PENDULO_H
