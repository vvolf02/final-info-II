#ifndef SPRITES_H
#define SPRITES_H

#include <QGraphicsPixmapItem>
#include <QTimer>
#include <QPixmap>

class sprites : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    sprites(const QPixmap &spriteSheet, int rows, int cols, int numFrames, int frameWidth, int frameHeight);

    void startAnimation();
    void stopAnimation();
    void setDirection(int direction);

private slots:
    void updateFrame();

private:
    QPixmap spriteSheet;
    int rows;
    int cols;
    int numFrames;
    int frameWidth;
    int frameHeight;
    int currentFrame;
    int currentDirection;
    QTimer *timer;
};

#endif // SPRITES_H
