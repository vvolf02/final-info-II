#ifndef MC_H
#define MC_H

#include "sprites.h"
#include <QGraphicsItem>

class mc : public sprites
{
public:
    mc(int x, int y, int vel);

    void MoverArriba();
    virtual void MoverAbajo();
    void MoverIzq();
    void MoverDer();
    void respawn();
    void saltar();
    void caer();
    void nuevovy(int vely);
    int getVel() const;
    int getX() const;
    int getY() const;
    int getVely() const;

private:
    int vel;
    int posx;
    int posy;
    int vely;
    double velSalto=-10;
    double gravity=1;
};

#endif // MC_H
