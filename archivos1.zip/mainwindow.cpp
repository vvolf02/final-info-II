#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <fstream>
#include <QGraphicsPixmapItem>
#include <QGraphicsItem>
#include <QBrush>
#include <QPixmap>
#include <QFile>
#include <QMessageBox>

int vel, vy, posx, posy;
bool enElAire=false, volando=false;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)   
    , fase(true)
    , final(false)
    , ui(new Ui::MainWindow)
    , timeLeft(90)
    , score(0)
    , vidas(10)
{
    ui->setupUi(this);
    scene = new QGraphicsScene();
    scene->setSceneRect(0, 0, 867, 389);
    QPixmap background(":/Imagen/marmol.jpg");
    scene->setBackgroundBrush(background);
    ui->graphicsView->setScene(scene);
    cambio = new class cambio(349, 205, 172, 62);
    scene->addItem(cambio);
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateTeclas);
    timer->start(24); // Aproximadamente 60 FPS
    // Iniciar el timer de gravedad
    gravedadTimer = new QTimer(this);
    connect(gravedadTimer, &QTimer::timeout, this, &MainWindow::gravedad);
    gravedadTimer->start(24); // Aproximadamente 60 FPS
    reboteTimer = new QTimer(this);
    connect(reboteTimer, &QTimer::timeout, this, &MainWindow::gravedadRebote);
    reboteTimer->start(24);
    ui->lcdNumber_2->display(score);
    ui->graphicsView->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
    cargarEscena();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    //qDebug() << "Tecla presionada:" << event->key();
    keyState[event->key()] = true;
}

void MainWindow::keyReleaseEvent(QKeyEvent *event)
{
    //qDebug() << "Tecla soltada:" << event->key();
    keyState[event->key()] = false;
}

void MainWindow::updateTeclas()
{
    if (keyState[Qt::Key_W])
    {
        vel = prota->getVel();
        posx = prota->getX();
        posy = prota->getY();
        //qDebug()<<"Tecla W presionada. Vel:"<<vel<<" Posición:"<<posx<<","<< posy;
        if (!detectarColision(0, -vel, posx, posy))
        {
            if (!fase && !enElAire)
            {
                prota->saltar();
                enElAire=true;
            }
            else if (fase)
            {
                prota->MoverArriba();
                colPuntos();
            }
        }
    }
    if (keyState[Qt::Key_S])
    {
        vel = prota->getVel();
        posx = prota->getX();
        posy = prota->getY();
        //qDebug()<<"Tecla S presionada. Vel:"<<vel <<" Posición:"<<posx<<","<<posy;
        if (!detectarColision(0, vel, posx, posy))
        {
            prota->MoverAbajo();
            EvaluarColision();
            colPuntos();
        }
    }
    if (keyState[Qt::Key_A])
    {
        vel = prota->getVel();
        posx = prota->getX();
        posy = prota->getY();
        //qDebug()<<"Tecla A presionada. Vel:" <<vel<<" Posición:"<<posx<<","<<posy;
        if (!detectarColision(-vel, 0, posx, posy))
        {
            prota->MoverIzq();
            colPuntos();
        }
    }
    if (keyState[Qt::Key_D])
    {
        vel = prota->getVel();
        posx = prota->getX();
        posy = prota->getY();
        //qDebug()<<"Tecla D presionada. Vel:"<<vel<<" Posición:"<<posx<<","<<posy;
        if (!detectarColision(vel, 0, posx, posy))
        {
            prota->MoverDer();
            EvaluarColision();
            colPuntos();
        }
    }
    colFuego();
}

void MainWindow::cargarEscena()
{
    // Crear el protagonista (mc)
    prota = new mc(23, 275, 12);
    scene->addItem(prota);

    // Cargar las paredes desde el archivo
    nuevasParedes("paredes.txt");

    // Cargar los puntos desde el archivo
    cargarPuntos("punticos.txt");

    // Iniciar el cronómetro
    ui->lcdNumber->display(timeLeft);
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateTimer);
    timer->start(1000);

    // Establecer la escena en el graphicsView
    ui->graphicsView->setScene(scene);
}

void MainWindow::cambioEscena()
{
    for(auto& item : paredes)
    {
        if (item)
        {
            scene->removeItem(item);
            delete item;
        }
    }
    paredes.clear();
    for(auto& item : punto)
    {
        if (item)
        {
            scene->removeItem(item);
            delete item;
        }
    }
    punto.clear();
    if (cambio)
    {
        scene->removeItem(cambio);
        delete cambio;
        cambio = nullptr;
    }
    if (prota)
    {
        scene->removeItem(prota);
        delete prota;
        prota = nullptr;
    }
    prota = new mc(20, 269, 12);
    scene->addItem(prota);
    fase = false;
    flama = new rebota(640, 100, 12);
    scene->addItem(flama);
    nuevasParedes("paredes2.txt");
    cargarFuego("fuego.txt");
    cambio = new class cambio(820, 259, 30, 50);
    scene->addItem(cambio);
    cambio->setTexture(":/Imagen/puerta2.png");
    timeLeft=90;
    ui->lcdNumber_2->display(vidas);
}

void MainWindow::cambioEscena2()
{
    for(auto& item : paredes)
    {
        if (item)
        {
            scene->removeItem(item);
            delete item;
        }
    }
    paredes.clear();
    for(auto& item : llamas)
    {
        if (item)
        {
            scene->removeItem(item);
            delete item;
        }
    }
    llamas.clear();
    if (cambio)
    {
        scene->removeItem(cambio);
        delete cambio;
        cambio = nullptr;
    }
    if (flama)
    {
        scene->removeItem(flama);
        delete flama;
        flama = nullptr;
    }
    prota->respawn();
    flama = new rebota(480, 100, 12);
    scene->addItem(flama);
    cambio = new class cambio(370, 40, 30, 50);
    scene->addItem(cambio);
    cambio->setTexture(":/Imagen/puerta2.png");
    nuevasParedes("paredes3.txt");
    cargarFuego("fuego2.txt");
    final=true;
}

void MainWindow::nuevasParedes(const std::string &filename)
{
    std::string row, posx, posy, ancho, alto;
    int x, y, h, al;
    std::ifstream file(filename);
    while (std::getline(file, row))
    {
        if (row.empty()) continue;
        posx = grupito(row, ',');
        x = std::stoi(posx);
        row = resize(row, ',');
        posy = grupito(row, ',');
        y = std::stoi(posy);
        row = resize(row, ',');
        ancho = grupito(row, ',');
        h = std::stoi(ancho);
        row = resize(row, ',');
        alto = grupito(row, ',');
        al = std::stoi(alto);
        pared *newPared = new pared(x, y, h, al);
        paredes.push_back(newPared);
        scene->addItem(newPared);
    }
    file.close();
}

void MainWindow::cargarFuego(const std::string &filename)
{
    std::string row, posx, posy, ancho, alto;
    int x, y, h, al;
    std::ifstream file(filename);
    while (std::getline(file, row))
    {
        if (row.empty()) continue;
        posx = grupito(row, ',');
        x = std::stoi(posx);
        row = resize(row, ',');
        posy = grupito(row, ',');
        y = std::stoi(posy);
        row = resize(row, ',');
        ancho = grupito(row, ',');
        h = std::stoi(ancho);
        row = resize(row, ',');
        alto = grupito(row, ',');
        al = std::stoi(alto);
        fuego *llama = new fuego(x, y, h, al);
        llamas.push_back(llama);
        scene->addItem(llama);
    }
    file.close();
}

void MainWindow::cargarPuntos(const std::string &filename)
{
    std::string row, posx, posy, radio;
    int x, y, r;
    std::ifstream archivo(filename);
    while (std::getline(archivo, row))
    {
        if (row.empty()) continue;
        posx = grupito(row, ',');
        x = std::stoi(posx);
        row = resize(row, ',');
        posy = grupito(row, ',');
        y = std::stoi(posy);
        row = resize(row, ',');
        radio = grupito(row, ',');
        r = std::stoi(radio);
        puntos *n_puntos = new puntos(x, y, r);
        punto.push_back(n_puntos);
        scene->addItem(n_puntos);
    }
    archivo.close();
}

void MainWindow::colPuntos()
{
    for (int i = punto.size() - 1; i >= 0; i--)
    {
        if (punto.at(i)->collidesWithItem(prota))
        {
            scene->removeItem(punto.at(i));
            delete punto.at(i);
            punto.erase(punto.begin() + i); // Eliminar el punto de la lista
            score++; // Incrementar marcador
            ui->lcdNumber_2->display(score); // Actualizar valor del LCD
        }
    }
}

void MainWindow::colFuego()
{
    for(int i = llamas.size() - 1; i >= 0; i--)
    {
        if (llamas.at(i)->collidesWithItem(prota) || flama->collidesWithItem(prota)) // Asegúrate de usar prota
        {
            prota->respawn();
            vidas--;
            ui->lcdNumber_2->display(vidas); // Asume que lcdNumber_2 muestra las vidas restantes
            if(vidas == 0)
            {
                timer->stop();
                gravedadTimer->stop();
                ui->lcdNumber_2->display(vidas);
                gameover();
            }
        }
    }
}

void MainWindow::updateTimer()
{
    if(timeLeft > 0)
    {
        timeLeft--;
        ui->lcdNumber->display(timeLeft);
        if(timeLeft == 0)
        {
            timer->stop();
            gameover();
        }
    }
}

void MainWindow::gravedad()
{
    if (!fase && prota)
    {
        vy=prota->getVely();
        efectoGravedad(vy);
    }
}

void MainWindow::efectoGravedad(int vely)
{
    posx = prota->getX();
    posy = prota->getY();

    // Aumentar la velocidad de caída (gravedad)
    vely += 1;

    // Limitar la velocidad de caída
    if (vely > 9)
        vely = 9;

    // Verificar colisiones con el suelo
    if (detectarColision(0, vely, posx, posy))
    {
        vely = 0; // Detener la velocidad de caída
        enElAire = false; // El personaje ha tocado el suelo
    }
    else
    {
        prota->caer();
    }

    prota->nuevovy(vely);
}

void MainWindow::gravedadRebote()
{
    if (!fase && flama)
    {
        flama->actualizar();
    }
}

void MainWindow::gameover()
{
    pared *npared = new pared(0, 0, 870, 392);
    npared->setTexture(":/Imagen/gameover.jpg");
    scene->addItem(npared);
}

void MainWindow::completado()
{
    pared *npared = new pared(0, 0, 870, 392);
    npared->setTexture(":/Imagen/win.jpg");
    scene->addItem(npared);
}

std::string MainWindow::resize(std::string row, char caracter)
{
    std::string fila = "";
    int posicion = row.find(caracter);
    int tamano = row.size();
    for(int i = posicion + 1; i < tamano; i++)
    {
        fila += row[i];
    }
    return fila;
}

std::string MainWindow::grupito(std::string row, char caracter)
{
    std::string grupo = "";
    int posicion = row.find(caracter);
    for(int i = 0; i < posicion; i++)
    {
        grupo += row[i];
    }
    return grupo;
}

void MainWindow::EvaluarColision()
{
    if (!cambio || !prota)
    {
        qDebug() << "Error: cambio o prota es nullptr";
        return;
    }

    if(fase && cambio->collidesWithItem(prota))
    {
        qDebug() << "Fase: " << fase << ", colisión con cambio detectada.";
        if(score == 10)
        {
            qDebug() << "Score es 10, cambiando escena.";
            cambioEscena();
        }
    }
    else if(!final && !fase && cambio->collidesWithItem(prota))
    {
        qDebug() << "Fase: " << fase << ", colisión con cambio detectada.";
        cambioEscena2();
    }
    if(final && cambio->collidesWithItem(prota))
    {
        completado();
        timer->stop();
    }
}

QRectF MainWindow::boundingRect() const
{
    return QRectF(0, 0, 24, 24);
}

bool MainWindow::detectarColision(int dx, int dy, int posx, int posy)
{
    // Crea un rectángulo en la posición futura del objeto
    QRectF futureRect = boundingRect().translated(posx + dx, posy + dy);

    // Obtiene una lista de elementos en la posición futura
    QList<QGraphicsItem*> itemsColisionados = scene->items(futureRect);

    foreach(QGraphicsItem * item, itemsColisionados)
    {
        if (dynamic_cast<pared*>(item))
        {
            //qDebug() << "Colisión detectada con una pared en:" << item->pos();
            return true;
        }
    }
    return false;
}
