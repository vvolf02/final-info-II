#include "mc.h"
#include <QGraphicsScene>
#include <QGraphicsItem>

mc::mc()
{

}

mc::mc(int x, int y, int r)
{
    posx=x;
    posy=y;
    radio=r;
    vely=0;
    setPos(posx, posy);
}

QRectF mc::boundingRect() const
{
    return QRectF(0, 0, 2*radio, 2*radio);
}

void mc::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::black);
    painter->drawEllipse(boundingRect());
    // QPixmap pixmap(":/Imagen/pacman.png");
    // painter->drawPixmap(boundingRect(), pixmap, pixmap.rect());
}

void mc::MoverDer()
{
    posx+=vel;
    setPos(posx, posy);
}

void mc::MoverIzq()
{
    posx-=vel;
    setPos(posx, posy);
}

void mc::MoverArriba()
{
    posy-=vel;
    setPos(posx, posy);
}

void mc::MoverAbajo()
{
    posy+=vel;
    setPos(posx, posy);
}

void mc::respawn()
{
    posx=20;
    posy=272;
    setPos(posx, posy);
}

void mc::caer()
{
    posy+=vely;
    setPos(posx, posy);
}

void mc::saltar()
{
    vely=velSalto; // Establecer la velocidad inicial del salto
}

void mc::nuevovy(int vy)
{
    vely=vy;
}

double mc::getVely() const
{
    return vely;
}

double mc::getX() const
{
    return posx;
}

double mc::getY() const
{
    return posy;
}

double mc::getVel() const
{
    return vel;
}
