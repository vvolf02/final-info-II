#ifndef REBOTA_H
#define REBOTA_H

#include <QGraphicsItem>
#include <QPainter>
#include <QGraphicsScene>

class rebota : public QGraphicsItem
{
    int posx, posy, radio;
    double vel, acc, velRebote;
public:
    rebota();
    rebota(int x, int y, int r);
    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    void actualizar();
    double getX() const;
    double getY() const;
    void nuevoRebote(double vely);
};

#endif // REBOTA_H
