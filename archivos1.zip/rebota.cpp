#include "rebota.h"

rebota::rebota()
    : posx(0), posy(0), radio(10), vel(0), acc(0.5), velRebote(-15)
{
}

rebota::rebota(int x, int y, int r)
    : posx(x), posy(y), radio(r), vel(0), acc(0.5), velRebote(-15)
{
    setPos(posx, posy);
}

QRectF rebota::boundingRect() const
{
    return QRectF(0, 0, 2 * radio, 2 * radio);
}

void rebota::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QPixmap pixmap(":/Imagen/fuego.png");
    painter->drawPixmap(boundingRect(), pixmap, pixmap.rect());
}

void rebota::actualizar()
{
    vel += acc;
    posy += static_cast<int>(vel);
    if (posy >= 300)  // Supongamos que 300 es el suelo
    {
        vel = velRebote;
    }
    setPos(posx, posy);
}

double rebota::getX() const
{
    return posx;
}

double rebota::getY() const
{
    return posy;
}

void rebota::nuevoRebote(double vely)
{
    velRebote = vely;
}
