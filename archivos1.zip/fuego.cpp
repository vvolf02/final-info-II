#include "fuego.h"

fuego::fuego()
{

}

fuego::fuego(int x, int y, int w, int h)
    : QGraphicsRectItem(x, y, w, h)
{
    this->posx=x;
    this->posy=y;
    this->h=h;
    this->w=w;
    currentTexture=QPixmap(":/Imagen/fuego2.png");
    setBrush(QBrush(currentTexture));
}

QRectF fuego::boundingRect() const
{
    return QRectF(posx,posy,w,h);
}

void fuego::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(boundingRect(), currentTexture, currentTexture.rect());
}
