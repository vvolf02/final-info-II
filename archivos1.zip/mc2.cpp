#include "mc2.h"

mc2::mc2(int x, int y, int r) : mc(x, y, r)
{
    radio = r;
    posx = x;
    posy = y;
    vel = 5;
    vely = 0;
    setPos(posx, posy);
}

QRectF mc2::boundingRect() const
{
    return QRectF(0, 0, 2 * radio, 2 * radio);
}

void mc2::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::blue); // Color del objeto
    painter->drawEllipse(boundingRect()); // Dibuja el objeto como un círculo
    // QPixmap pixmap(":/Imagen/imagen_mc2.png");
    // painter->drawPixmap(boundingRect(), pixmap, pixmap.rect());
}
/*
void mc2::MoverArriba()
{
    posy-=25;
    setPos(posx, posy);
}*/

void mc2::MoverAbajo()
{
    // Puedes dejar esta función vacía o implementar un movimiento descendente adicional si es necesario
}



void mc2::cambiarPos(int x, int y)
{
    setPos(x, y);
}

void mc2::nuevoVely(int vy)
{
    vely=vy;
}

double mc2::getVely()
{
    return vely;
}

void mc2::caer()
{
    posy += vel;
    setPos(posx, posy);
}

/*void mc2::CalcularVelocidad()
{
    velx = vel * cos(ang);
    vely = vel * sin(ang);
}

void mc2::CalcularPosicion()
{
    posx = posx + velx * 0.1;
    posy = posy + vely * 0.1 - (0.5 * 9.8 * pow(0.1, 2));
    setPos(posx, -posy);
}

void mc2::ActualizarVelocidad()
{
    vel = sqrt(pow(velx, 2) + pow(vely, 2));
    ang = atan2(vely, velx);
}*/

