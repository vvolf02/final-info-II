#ifndef MC_H
#define MC_H
#include <QGraphicsItem>
#include <QPainter>
#include <QPixmap>

class mc : public QGraphicsItem
{
    int posx, posy, radio;
    double vely;
    double vel = 5; // velocidad de movimiento horizontal
    double velSalto = -10; // velocidad inicial del salto
    double gravity = 1;
public:
    mc();
    mc(int x, int y, int r);
    QRectF boundingRect() const override;
    void paint(QPainter *painter,
               const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    virtual void MoverDer();
    virtual void MoverIzq();
    virtual void MoverArriba();
    virtual void MoverAbajo();
    double getX() const;
    double getY() const;
    double getVel() const;
    double getVely() const;
    void respawn();
    void caer();
    void nuevovy(int vy);
    void saltar();
    //bool detectarColision(int dx, int dy);
};

#endif // MC_H
