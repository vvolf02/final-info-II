#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QKeyEvent>
#include <QList>
#include <string>
#include <QTimer>
#include "mc.h"
#include "mc2.h"
#include "puntos.h"
#include "pared.h"
#include "cambio.h"
#include "fuego.h"
#include "rebota.h"

using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event) override;
    bool fase=true;

private slots:
    void updateTimer();
    void gravedad();
    void gravedadRebote();
    void updateTeclas();

private:
    Ui::MainWindow *ui;
    mc *prota;
    mc2 *prota2;
    cambio *cambio;
    rebota *flama;
    QGraphicsScene *scene;
    QList<pared *> paredes;
    QList<puntos *> punto;
    QList<fuego *> llamas;
    QTimer *timer;
    QTimer *gravedadTimer;
    QTimer *reboteTimer;
    QRectF boundingRect() const;
    int timeLeft;
    int score;
    int vidas;
    QMap<int, bool> keyState;
    string resize(string row, char caracter);
    string grupito(string row, char caracter);
    void efectoGravedad(int vely);
    void movRebote(int velR);
    void EvaluarColision();
    void colPuntos();
    void colFuego();
    void gameover();
    void cargarEscena();
    void cambioEscena();
    void cambioEscena2();
    void nuevasParedes(const string &filename);
    void cargarPuntos(const string &filename);
    void cargarFuego(const string &filename);
    bool detectarColision(int dx, int dy, int posx, int posy);

};

#endif // MAINWINDOW_H
