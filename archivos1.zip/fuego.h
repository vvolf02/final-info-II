#ifndef FUEGO_H
#define FUEGO_H
#include <QGraphicsRectItem>
#include <QBrush>
#include <QPixmap>
#include <QPainter>

class fuego: public QGraphicsRectItem
{
    int posx, posy, w, h;
    QPixmap currentTexture;
public:
    fuego();
    fuego(int posx, int posy, int w, int h);
    QRectF boundingRect() const;
    void paint(QPainter *painter,
               const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr);
};

#endif // FUEGO_H
