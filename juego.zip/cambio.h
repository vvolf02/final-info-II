#ifndef CAMBIO_H
#define CAMBIO_H

#include <QGraphicsRectItem>
#include <QBrush>
#include <QPixmap>
#include <QPainter>

class cambio: public QGraphicsRectItem
{
    int posx, posy, w, h;
    QPixmap currentTexture;
public:
    cambio(int posx, int posy, int w, int h);
    QRectF boundingRect() const;
    void paint(QPainter *painter,
               const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr);
};

#endif // CAMBIO_H
