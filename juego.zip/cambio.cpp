#include "cambio.h"

cambio::cambio(int x, int y, int w, int h) : QGraphicsRectItem(x, y, w, h)
{
    this->posx=x;
    this->posy=y;
    this->h=h;
    this->w=w;
    currentTexture=QPixmap(":/Imagen/escaleras.jpg");
    setBrush(QBrush(currentTexture));
}

QRectF cambio::boundingRect() const
{
    return QRectF(posx,posy,w,h);
}

void cambio::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(boundingRect(), currentTexture, currentTexture.rect());
}
