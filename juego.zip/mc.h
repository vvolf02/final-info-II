#ifndef MC_H
#define MC_H
#include <QGraphicsItem>
#include <QPainter>
#include <QPixmap>

class mc : public QGraphicsItem
{
    int posx, posy, radio, vely, vel = 5;
public:
    mc();
    mc(int x, int y, int r);
    QRectF boundingRect() const override;
    void paint(QPainter *painter,
               const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    virtual void MoverDer();
    virtual void MoverIzq();
    virtual void MoverArriba();
    virtual void MoverAbajo();
    double getX() const;
    double getY() const;
    double getVel() const;
    double getVely() const;
    void respawn();
    void caer();
    void nuevovy(int vy);
    void saltar();
    //bool detectarColision(int dx, int dy);
};

#endif // MC_H
