#ifndef MC_H
#define MC_H
#include <QGraphicsItem>
#include <QPainter>
#include <QPixmap>

class mc : public QGraphicsItem
{
    int posx, posy, radio, vel = 10;
public:
    mc();
    mc(int x, int y, int r);
    QRectF boundingRect() const override;
    void paint(QPainter *painter,
               const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    virtual void MoverDer();
    virtual void MoverIzq();
    virtual void MoverArriba();
    virtual void MoverAbajo();
    void respawn();
    bool detectarColision(int dx, int dy);
};

#endif // MC_H
