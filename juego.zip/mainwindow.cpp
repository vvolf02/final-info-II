#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <fstream>
#include <QGraphicsPixmapItem>
#include <QBrush>
#include <QPixmap>
#include <QFile>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , score(0)
    , timeLeft(90)
{

    ui->setupUi(this);
    scene = new QGraphicsScene();
    scene->setSceneRect(0, 0, 867, 389);
    QPixmap background(":/Imagen/marmol.jpg");
    scene->setBackgroundBrush(background);
    ui->graphicsView->setScene(scene);
    pared* npared=new pared(349, 205, 172, 62, 1);
    npared->setTexture(":/Imagen/escaleras.jpg");
    paredes.push_back(npared);
    scene->addItem(paredes.back());
    cargarEscena();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    // Manejar los eventos de teclado para prota
    if (event->key() == Qt::Key_W)
    {
        if(fase)
        {
            if (!EvaluarColision())
                prota->MoverArriba();
            else
                prota->MoverAbajo();
            colPuntos();
        }
        else
        {
            timer2->start(10);
            connect(timer,SIGNAL(timeout()),this,SLOT(Actualizar()));
        }
    }
    else if (event->key() == Qt::Key_S)
    {
        if(fase)
        {
            if (!EvaluarColision())
                prota->MoverAbajo();
            else
                prota->MoverArriba();
            colPuntos();
        }
    }
    else if (event->key() == Qt::Key_D)
    {
        if(fase)
        {
            if (!EvaluarColision())
                prota->MoverDer();
            else
                prota->MoverIzq();
            colPuntos();
        }
        else
        {
            prota->MoverDer();
        }
    }
    else if (event->key() == Qt::Key_A)
    {
        if(fase)
        {
            if (!EvaluarColision())
                prota->MoverIzq();
            else
                prota->MoverDer();
            colPuntos();
        }
        else
        {
            prota->MoverIzq();
        }
    }
}

void MainWindow::cargarEscena()
{
    // Crear el protagonista (mc)
    prota = new mc(13, 175, 12);
    scene->addItem(prota);

    // Cargar las paredes desde el archivo
    nuevasParedes("paredes.txt");

    // Cargar los puntos desde el archivo
    cargarPuntos("punticos.txt");

    // Iniciar el cronómetro
    ui->lcdNumber->display(timeLeft);
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateTimer);
    timer->start(1000);

    // Establecer la escena en el graphicsView
    ui->graphicsView->setScene(scene);
}

void MainWindow::cambioEscena()
{
    // Eliminar los objetos y limpiar la escena
    for(auto& item : paredes)
    {
        scene->removeItem(item);
        delete item;
    }
    paredes.clear();
    for(auto& item : punto)
    {
        scene->removeItem(item);
        delete item;
    }
    punto.clear();
    timeLeft = 90;
    scene->removeItem(prota);
    delete prota;
    timer2= new QTimer();
    // Crear a mc2 después del cambio de escena
    prota = new mc2(113, 175, 12);
    scene->addItem(prota);

    // Volver a cargar las paredes para el nuevo nivel
    nuevasParedes("paredes2.txt");
}

void MainWindow::Actualizar()
{
    prota->MoverArriba();
}

void MainWindow::nuevasParedes(const string &filename)
{
    // Cargar las paredes desde el archivo
    string row, posx, posy, ancho, alto;
    int x, y, h, al;
    ifstream file(filename);
    while (getline(file, row))
    {
        if (row.empty()) continue;
        posx = grupito(row, ',');
        x = stoi(posx);
        row = resize(row, ',');
        posy = grupito(row, ',');
        y = stoi(posy);
        row = resize(row, ',');
        ancho = grupito(row, ',');
        h = stoi(ancho);
        row = resize(row, ',');
        alto = grupito(row, ',');
        al = stoi(alto);
        int id = 0;
        pared *newPared = new pared(x, y, h, al, id);
        paredes.push_back(newPared);
        scene->addItem(newPared);
    }
    file.close();
}

void MainWindow::cargarPuntos(const string &filename)
{
    // Cargar los puntos desde el archivo
    string row, posx, posy, radio;
    int x, y, r;
    ifstream archivo(filename);
    while (getline(archivo, row))
    {
        if (row.empty()) continue;
        posx = grupito(row, ',');
        x = stoi(posx);
        row = resize(row, ',');
        posy = grupito(row, ',');
        y = stoi(posy);
        row = resize(row, ',');
        radio = grupito(row, ',');
        r = stoi(radio);
        puntos *n_puntos = new puntos(x, y, r);
        punto.push_back(n_puntos);
        scene->addItem(n_puntos);
    }
    archivo.close();
}

void MainWindow::colPuntos()
{
    for (int i = punto.size() - 1; i >= 0; i--)
    {
        if (punto.at(i)->collidesWithItem(prota))
        {
            scene->removeItem(punto.at(i));
            delete punto.at(i);
            punto.erase(punto.begin() + i); // Eliminar el punto de la lista
            score++; // Incrementar marcador
            ui->lcdNumber->display(score); // Actualizar valor del LCD
        }
    }
}

void MainWindow::updateTimer()
{
    if(timeLeft > 0)
    {
        timeLeft--;
        ui->lcdNumber->display(timeLeft);
        if(timeLeft == 0)
        {
            timer->stop();
            gameover();
        }
    }
}

void MainWindow::gameover()
{
    pared *npared = new pared(0, 0, 870, 392, 0);
    npared->setTexture(":/Imagen/gameover.jpg");
    scene->addItem(npared);
}

string MainWindow::resize(string row, char caracter)
{
    string fila = "";
    int posicion = row.find(caracter);
    int tamano = row.size();
    for(int i = posicion + 1; i < tamano; i++)
    {
        fila += row[i];
    }
    return fila;
}

string MainWindow::grupito(string row, char caracter)
{
    string grupo = "";
    int posicion = row.find(caracter);
    for(int i = 0; i < posicion; i++)
    {
        grupo += row[i];
    }
    return grupo;
}

bool MainWindow::EvaluarColision()
{
    for(int i = 0; i < paredes.size(); i++)
    {
        if(paredes.at(i)->collidesWithItem(prota))
        {
            if(paredes.at(i)->getId() == 1 && score == 10)
            {
                cambioEscena();
                nuevasParedes("paredes2.txt");
            }
            return true;
        }
    }
    return false;
}
