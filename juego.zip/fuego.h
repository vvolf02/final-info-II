#ifndef FUEGO_H
#define FUEGO_H
#include "pared.h"

class fuego: public pared
{
public:

};

#endif // FUEGO_H
