#include "mc2.h"


mc2::mc2(int x, int y, int r) : mc(x, y, r)
{
    radio=r;
    posx=x;
    posy=y;
    setPos(posx, posy);
}

QRectF mc2::boundingRect() const
{
    return QRectF(posx, posy, 2*radio, 2*radio);
}

void mc2::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::blue); // Color del objeto
    painter->drawEllipse(boundingRect()); // Dibuja el objeto como un círculo
    // QPixmap pixmap(":/Imagen/imagen_mc2.png");
    // painter->drawPixmap(boundingRect(), pixmap, pixmap.rect());
}
void mc2::MoverDer()
{
    posx+=vel;
    setPos(posx,posy);
}

void mc2::MoverIzq()
{
    posx-=vel;
    setPos(posx,posy);
}

void mc2::MoverArriba()
{
    CalcularVelocidad();
    CalcularPosicion();
    ActualizarVelocidad();
}

void mc2::MoverAbajo()
{

}

double mc2::getX() const
{
    return posx;
}

double mc2::getY() const
{
    return posy;
}

void mc2::CalcularVelocidad()
{
    velx=vel*cos(ang);
    vely=vel*sin(ang);
}

void mc2::CalcularPosicion()
{
    posx=posx+velx*0.1;
    posy=posy+vely*0.1-(0.5*9.8*pow(0.1,2));
    setPos(posx,-posy);
}


void mc2::ActualizarVelocidad()
{
    vel=sqrt(pow(velx,2)+pow(vely,2));
    ang=atan2(vely,velx);
}

void mc2::advance(int phase)
{
    if(phase == 0) return;

    // Aplicar gravedad
    vely += 1; // Gravedad constante

    // Limitar velocidad de caída
    if (vely > 15) vely = 15;

    // Mover verticalmente
    posy += vely;
    setPos(posx, posy);

    // Verificar colisiones con el suelo
    if (posy >= 175) { // 175 es la altura del suelo
        posy = 175;
        vely = 0;
    }
}
