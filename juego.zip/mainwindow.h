#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QList>
#include <string>
#include <QTimer>
#include "mc.h"
#include "mc2.h"
#include "puntos.h"
#include "pared.h"
#include "cambio.h"

using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void keyPressEvent(QKeyEvent *event);
    bool fase=true;

private slots:
    void updateTimer();
    void Actualizar();
    void gravedad();

private:
    Ui::MainWindow *ui;
    mc *prota;
    mc2 *prota2;
    cambio *cambio;
    QGraphicsScene *scene;
    QList<pared *> paredes;
    QList<puntos *> punto;
    QTimer *timer;
    QTimer *gravedadTimer;
    int timeLeft;
    int score;
    string resize(string row, char caracter);
    string grupito(string row, char caracter);
    void EvaluarColision();
    void colPuntos();
    void gameover();
    void cargarEscena();
    void cambioEscena();
    void nuevasParedes(const string &filename);
    void cargarPuntos(const string &filename);
};

#endif // MAINWINDOW_H
