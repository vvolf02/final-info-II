#ifndef MC2_H
#define MC2_H

#include <QGraphicsItem>
#include <QPainter>
#include <QTimer>
#include "mc.h"

class mc2 : public mc
{
    double velx, vely, posx, posy, radio;
    int timerUp, timerDown;
    bool jump;
    double vel = 5;
    double ang = 70;
public:
    mc2(int x, int y, int r);
    QRectF boundingRect() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    void MoverDer() override;
    void MoverIzq() override;
    void MoverArriba() override;
    void MoverAbajo() override;
    double getX() const;
    double getY() const;
    void CalcularVelocidad();
    void CalcularPosicion();
    void ActualizarVelocidad();
    void efectoGravedad();

protected:
    void advance(int phase) override;
};

#endif // MC2_H
