#include "mc.h"
#include "pared.h"
#include <QGraphicsScene>
#include <QGraphicsItem>

mc::mc()
{

}

mc::mc(int x, int y, int r)
{
    posx = x;
    posy = y;
    radio = r;
    setPos(posx, posy);
}

QRectF mc::boundingRect() const
{
    return QRectF(0, 0, 2 * radio, 2 * radio);
}

void mc::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setBrush(Qt::black);
    painter->drawEllipse(boundingRect());
    // QPixmap pixmap(":/Imagen/pacman.png");
    // painter->drawPixmap(boundingRect(), pixmap, pixmap.rect());
}

void mc::MoverDer()
{
    if (!detectarColision(vel, 0))
    {
        posx += vel;
        setPos(posx, posy);
    }
}

void mc::MoverIzq()
{
    if (!detectarColision(-vel, 0))
    {
        posx -= vel;
        setPos(posx, posy);
    }
}

void mc::MoverArriba()
{
    if (!detectarColision(0, -vel))
    {
        posy -= vel;
        setPos(posx, posy);
    }
}

void mc::MoverAbajo()
{
    if (!detectarColision(0, vel))
    {
        posy += vel;
        setPos(posx, posy);
    }
}

void mc::respawn()
{
    posx = 13;
    posy = 175;
    setPos(posx, posy);
}

bool mc::detectarColision(int dx, int dy)
{
    // Crea un rectángulo en la posición futura del objeto
    QRectF futureRect = boundingRect().translated(posx + dx, posy + dy);

    // Obtiene una lista de elementos en la posición futura
    QList<QGraphicsItem*> itemsColisionados = scene()->items(futureRect);

    foreach(QGraphicsItem * item, itemsColisionados)
    {
        if (dynamic_cast<pared*>(item))
        {
            return true;
        }
    }
    return false;
}
